
  # Optimize Route Functionality

  This is a code bundle for Optimize Route Functionality. The original project is available at https://www.figma.com/design/ODwduy9WrW21UObaYaI5mx/Optimize-Route-Functionality.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  